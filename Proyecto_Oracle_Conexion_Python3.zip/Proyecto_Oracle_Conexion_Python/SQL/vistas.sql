-- Vista 1: Reporte Simplificado de Pedidos y Clientes
CREATE OR REPLACE VIEW V_REPORTE_PEDIDOS_CLIENTE AS
SELECT 
    p.Cod_Ped,
    c.Nombre || ' ' || c.Apellido AS Cliente_Completo,
    p.fecha_pedido,
    p.estado
FROM 
    PEDIDOS p
INNER JOIN 
    CLIENTES c ON p.Cod_Client = c.Cod_Client;


-- Vista 2: Listado de Productos sin Stock
CREATE OR REPLACE VIEW V_PRODUCTOS_LISTADO AS
SELECT
    Cod_Prod,
    Nom_Prod,
    Precio
FROM
    PRODUCTOS;