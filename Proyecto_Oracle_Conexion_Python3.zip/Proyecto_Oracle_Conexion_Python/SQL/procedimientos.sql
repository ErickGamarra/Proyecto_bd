CREATE OR REPLACE PROCEDURE PRC_REGISTRAR_VENTA (
    p_cod_ped     IN NUMBER,
    p_cod_client  IN NUMBER,
    p_cod_prod    IN NUMBER,
    p_cantidad    IN NUMBER,
    p_precio_total IN NUMBER,
    p_fecha       IN DATE DEFAULT SYSDATE -- ESTE ES EL 6° PARÁMETRO CLAVE
)
AS
    v_stock_actual NUMBER;
    e_stock_insuficiente EXCEPTION; 
    PRAGMA EXCEPTION_INIT(e_stock_insuficiente, -20001);

BEGIN
    -- Lógica de Stock y DML completa...
    SELECT Stock INTO v_stock_actual
    FROM PRODUCTOS
    WHERE Cod_Prod = p_cod_prod;
    
    IF v_stock_actual < p_cantidad THEN
        RAISE_APPLICATION_ERROR(-20001, 'ERROR: Stock insuficiente...');
    END IF;

    INSERT INTO PEDIDOS (Cod_Ped, Cod_Client, fecha_pedido, estado)
    VALUES (p_cod_ped, p_cod_client, SYSDATE, 'Procesando'); -- Usamos SYSDATE

    INSERT INTO DETALLE_PEDIDO (Cod_Ped, Cod_Prod, Cantidad, Precio_Total)
    VALUES (p_cod_ped, p_cod_prod, p_cantidad, p_precio_total);
    
    UPDATE PRODUCTOS SET Stock = Stock - p_cantidad WHERE Cod_Prod = p_cod_prod;

EXCEPTION
    WHEN NO_DATA_FOUND THEN RAISE_APPLICATION_ERROR(-20002, 'ERROR: El Producto o Cliente no existe.');
    WHEN e_stock_insuficiente THEN RAISE;
    WHEN OTHERS THEN RAISE_APPLICATION_ERROR(-20003, 'ERROR INESPERADO: Detalle: ' || SQLERRM);
END;
/