-- 1. CREACIÓN DE SECUENCIA (Para auto-incremento en 11g)
CREATE SEQUENCE audit_precios_seq
 START WITH 1 
 INCREMENT BY 1 
 NOCACHE 
 NOCYCLE;

-- 2. CREACIÓN DE TABLA (Sin la sintaxis IDENTITY)
CREATE TABLE AUDIT_PRECIOS (
    Audit_ID NUMBER(10) NOT NULL, -- Ya no es IDENTITY, el trigger le asignará el valor
    Cod_Prod NUMBER(8) NOT NULL,
    Precio_Anterior NUMBER(6, 2) NOT NULL,
    Precio_Nuevo NUMBER(6, 2) NOT NULL,
    Fecha_Cambio DATE DEFAULT SYSDATE NOT NULL,
    Usuario_Cambio VARCHAR2(30) DEFAULT USER NOT NULL,
    CONSTRAINT PK_AUDIT_PRECIOS PRIMARY KEY (Audit_ID)
);


CREATE OR REPLACE TRIGGER TRG_AUDIT_ID
BEFORE INSERT ON AUDIT_PRECIOS
FOR EACH ROW
BEGIN
  -- Asigna el siguiente valor de la secuencia al ID antes de la inserción
  :NEW.Audit_ID := audit_precios_seq.NEXTVAL;
END;
/


CREATE OR REPLACE TRIGGER TRG_AUDIT_PRECIO_PRODUCTO
BEFORE UPDATE OF Precio ON PRODUCTOS
FOR EACH ROW
WHEN (OLD.Precio != NEW.Precio) -- SINTAXIS COMPATIBLE CON 11G
BEGIN
    INSERT INTO AUDIT_PRECIOS (
        Cod_Prod,
        Precio_Anterior,
        Precio_Nuevo
    )
    VALUES (
        :OLD.Cod_Prod,
        :OLD.Precio,      
        :NEW.Precio       
    );
END;
/