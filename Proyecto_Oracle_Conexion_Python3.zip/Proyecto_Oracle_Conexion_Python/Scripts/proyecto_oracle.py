import oracledb
from conexion_oracle import get_connection

# FUNCIONES BASE - MÉTODOS, FUNCIONES, COMMIT

def ejecutar_transaccion(sql, params=None, is_select=False):
    conn, cur = None, None
    resultados = []
    try:
        conn = get_connection()
        cur = conn.cursor()
        if params:
            cur.execute(sql, params)
        else:
            cur.execute(sql)
        if is_select:
            resultados = cur.fetchall()
        else:
            conn.commit()
    except oracledb.Error as e:
        print(f"ERROR DE ORACLE: {e}")
        if conn and not is_select:
            conn.rollback()
    finally:
        if cur: cur.close()
        if conn: conn.close()
    return resultados

# CLIENTES - MÉTODOS

def insertar_cliente(cod, nombre, apellido, dni, telefono, correo, direccion):
    sql = """
        INSERT INTO CLIENTES (Cod_Client, Nombre, Apellido, DNI, Telefono, Correo, Direccion)
        VALUES (:1, :2, :3, :4, :5, :6, :7)
    """
    ejecutar_transaccion(sql, (cod, nombre, apellido, dni, telefono, correo, direccion))

def obtener_clientes():
    sql = """
        SELECT Cod_Client, Nombre, Apellido, DNI, Telefono, Correo, Direccion
        FROM CLIENTES
        ORDER BY Cod_Client
    """
    return ejecutar_transaccion(sql, is_select=True)

# PEDIDOS - MÉTODOS

def actualizar_estado_pedido(cod_ped, nuevo_estado):
    sql = "UPDATE PEDIDOS SET estado = :nuevo_estado WHERE Cod_Ped = :cod_ped"
    ejecutar_transaccion(sql, {'nuevo_estado': nuevo_estado, 'cod_ped': cod_ped})

def consultar_reporte_pedidos():
    sql = """
        SELECT Cod_Ped, Cliente_Completo, fecha_pedido, estado
        FROM V_REPORTE_PEDIDOS_CLIENTE
        ORDER BY Cod_Ped DESC
    """
    return ejecutar_transaccion(sql, is_select=True)

# PRODUCTOS - MÉTODOS

def consultar_todos_productos():
    sql = "SELECT Nom_Prod, Precio, Stock, Cod_Prod FROM PRODUCTOS ORDER BY Nom_Prod"
    return ejecutar_transaccion(sql, is_select=True)

def insertar_producto(cod_prod, nom_prod, precio, stock):
    sql = """
        INSERT INTO PRODUCTOS (Cod_Prod, Nom_Prod, Precio, Stock)
        VALUES (:1, :2, :3, :4)
    """
    ejecutar_transaccion(sql, (cod_prod, nom_prod, precio, stock))

# PROCEDIMIENTO DE VENTAS - MÉTODOS

def registrar_venta_con_prc(cod_ped, cod_client, cod_prod, cantidad, precio_total):
    conn, cur = None, None
    try:
        conn = get_connection()
        cur = conn.cursor()
        params = [cod_ped, cod_client, cod_prod, cantidad, precio_total, None]
        cur.callproc("PRC_REGISTRAR_VENTA", params)
        conn.commit()
    except oracledb.Error as e:
        if conn: conn.rollback()
        raise Exception(f"Error al registrar venta: {e}")
    finally:
        if cur: cur.close()
        if conn: conn.close()
