import sys
import os
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime

# RUTA AÑADIDA PARA IMPORTACIÓN DIRECTA DE PYTHON (PATH NATIVO DE OS)
# IMPORTACIÓN DE FUNCIONES DEL .PY PROYECTO_ORACLE
# CONTROL DE ERRORES Y MANEJO DE DIRECTORIOS
try:
    directorio_actual = os.path.dirname(os.path.abspath(__file__))
    ruta_scripts = os.path.abspath(os.path.join(directorio_actual, os.pardir, 'Scripts'))
    sys.path.append(ruta_scripts)

    from proyecto_oracle import (
        consultar_reporte_pedidos,
        registrar_venta_con_prc,
        insertar_cliente,
        obtener_clientes,
        actualizar_estado_pedido,
        consultar_todos_productos,
        insertar_producto
    )
except ImportError as e:
    messagebox.showerror(
        "ERROR FATAL DE IMPORTACIÓN",
        f"No se pudieron encontrar las funciones en proyecto_oracle.py.\nDetalle: {e}"
    )
    sys.exit(1)


class App:
    def __init__(self, root):
        self.root = root
        self.root.title("Sistema de Ventas - Oracle + Python")
        self.root.geometry("950x650")

        self.crear_marcos()
        self.crear_formulario_ventas()
        self.crear_tabla_ventas()
        self.crear_modulo_clientes(self.tab_clientes)
        self.crear_modulo_productos(self.tab_productos)

# CREACIÓN DE PESTAÑAS - INTERFAZ VISUAL

    def crear_marcos(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill='both', expand=True, padx=10, pady=10)

        self.tab_ventas = ttk.Frame(self.notebook, padding="10")
        self.tab_clientes = ttk.Frame(self.notebook, padding="10")
        self.tab_productos = ttk.Frame(self.notebook, padding="10")

        self.notebook.add(self.tab_ventas, text='Venta y Reporte')
        self.notebook.add(self.tab_clientes, text='Gestión de Clientes')
        self.notebook.add(self.tab_productos, text='Gestión de Productos')

        # Frames de venta
        self.frame_form = tk.LabelFrame(self.tab_ventas, text="Registrar Venta", padx=10, pady=10)
        self.frame_form.pack(fill="x", padx=10, pady=10)
        self.frame_table = tk.LabelFrame(self.tab_ventas, text="Reporte de Pedidos", padx=10, pady=10)
        self.frame_table.pack(fill="both", expand=True, padx=10, pady=10)

# FORMULARIO DE VENTAS - FUNCIONES, GRIDS Y BOTONES DE REGISTRO

    def crear_formulario_ventas(self):
        labels = ["Cod Pedido", "Cod Cliente", "Cod Producto", "Cantidad", "Precio Total"]
        self.entries_ventas = {}
        for i, texto in enumerate(labels):
            tk.Label(self.frame_form, text=f"{texto}:").grid(row=i, column=0, padx=5, pady=2, sticky="w")
            entry = tk.Entry(self.frame_form)
            entry.grid(row=i, column=1, padx=5, pady=2)
            self.entries_ventas[texto] = entry

        tk.Button(self.frame_form, text="Registrar Venta", command=self.registrar_venta).grid(
            row=len(labels), column=0, columnspan=2, pady=10
        )

    # TABLA DE VENTAS - FUNCIONES Y CONTROL DE ERRORES

    def crear_tabla_ventas(self):
        columnas = ("Cod_Ped", "Cliente", "Fecha", "Estado")
        self.tabla_ventas = ttk.Treeview(self.frame_table, columns=columnas, show="headings")
        for col in columnas:
            self.tabla_ventas.heading(col, text=col)
            self.tabla_ventas.column(col, width=150)
        self.tabla_ventas.pack(fill="both", expand=True)

        tk.Button(self.frame_table, text="Actualizar Tabla", command=self.cargar_reporte).pack(pady=5)

    def registrar_venta(self):
        try:
            registrar_venta_con_prc(
                int(self.entries_ventas["Cod Pedido"].get()),
                int(self.entries_ventas["Cod Cliente"].get()),
                int(self.entries_ventas["Cod Producto"].get()),
                int(self.entries_ventas["Cantidad"].get()),
                float(self.entries_ventas["Precio Total"].get())
            )
            messagebox.showinfo("Éxito", "Venta registrada correctamente.")
            self.limpiar_ventas()
            self.cargar_reporte()
        except Exception as e:
            messagebox.showerror("Error de Oracle/Lógica", str(e))

    def limpiar_ventas(self):
        for entry in self.entries_ventas.values():
            entry.delete(0, tk.END)

    def cargar_reporte(self):
        for row in self.tabla_ventas.get_children():
            self.tabla_ventas.delete(row)
        try:
            registros = consultar_reporte_pedidos()
            if not registros:
                messagebox.showinfo("Reporte", "No hay datos disponibles.")
                return
            for r in registros:
                datos = list(r)
                if len(datos) > 2 and isinstance(datos[2], datetime):
                    datos[2] = datos[2].strftime("%d/%m/%y")
                self.tabla_ventas.insert("", "end", values=datos)
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo cargar el reporte.\nDetalle: {e}")

    # MÓDULO CLIENTES - GRIDS Y DETALLES DE CAJAS DE TEXTO

    def crear_modulo_clientes(self, tab):
        frame_form = tk.LabelFrame(tab, text="Registro de Clientes", padx=10, pady=10)
        frame_form.pack(fill='x', padx=5, pady=5)

        campos = ["Cod Cliente", "Nombre", "Apellido", "DNI", "Telefono", "Correo", "Direccion"]
        self.cliente_entries = {}
        for i, campo in enumerate(campos):
            tk.Label(frame_form, text=f"{campo}:").grid(row=i, column=0, padx=5, pady=2, sticky="w")
            entry = tk.Entry(frame_form, width=40)
            entry.grid(row=i, column=1, padx=5, pady=2)
            self.cliente_entries[campo] = entry

        tk.Button(frame_form, text="Insertar Cliente", command=self.insertar_nuevo_cliente_gui).grid(
            row=len(campos), column=0, columnspan=2, pady=10
        )

# Tabla de clientes - FRAMES, COLUMNAS Y BOTONES DE TEXTO

        frame_table = tk.LabelFrame(tab, text="Lista de Clientes", padx=10, pady=10)
        frame_table.pack(fill='both', expand=True, padx=5, pady=5)
        columnas = ("COD_CLIENTE", "NOMBRES", "APELLIDO", "DNI", "CELULAR", "CORREO", "DIRECCION")
        self.tree_clientes = ttk.Treeview(frame_table, columns=columnas, show="headings")
        for col in columnas:
            self.tree_clientes.heading(col, text=col)
            self.tree_clientes.column(col, width=120)
        self.tree_clientes.pack(fill='both', expand=True)

        tk.Button(frame_table, text="Actualizar Lista de Clientes", command=self.cargar_clientes).pack(pady=5)
        self.cargar_clientes()


    def insertar_nuevo_cliente_gui(self):
        try:
            valores = [
                int(self.cliente_entries["Cod Cliente"].get()),
                self.cliente_entries["Nombre"].get(),
                self.cliente_entries["Apellido"].get(),
                int(self.cliente_entries["DNI"].get()),
                int(self.cliente_entries["Telefono"].get()),
                self.cliente_entries["Correo"].get(),
                self.cliente_entries["Direccion"].get()
            ]
            insertar_cliente(*valores)
            messagebox.showinfo("Éxito", f"Cliente insertado (Cod: {valores[0]}).")
            for entry in self.cliente_entries.values():
                entry.delete(0, tk.END)
            self.cargar_clientes()
        except ValueError:
            messagebox.showerror("Error de Formato", "Revise los campos numéricos.")
        except Exception as e:
            messagebox.showerror("Error de Oracle", f"No se pudo insertar el cliente.\nDetalle: {e}")


    def cargar_clientes(self):
        for row in self.tree_clientes.get_children():
            self.tree_clientes.delete(row)
        try:
            registros = obtener_clientes()
            for r in registros:
                self.tree_clientes.insert("", "end", values=r)
        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron cargar los clientes.\nDetalle: {e}")

# MÓDULO PRODUCTOS - MÉTODOS Y FUNCIONES

    def crear_modulo_productos(self, tab):
        frame = tk.LabelFrame(tab, text="Gestión de Productos", padx=10, pady=10)
        frame.pack(fill='both', expand=True, padx=5, pady=5)

        columnas = ("Nombre", "Precio", "Stock", "Cod_Prod")
        self.tree_productos = ttk.Treeview(frame, columns=columnas, show="headings")
        for col in columnas:
            self.tree_productos.heading(col, text=col)
            self.tree_productos.column(col, width=150)
        self.tree_productos.pack(fill='both', expand=True)

        tk.Button(frame, text="Actualizar Lista de Productos", command=self.cargar_productos).pack(pady=5)
        tk.Button(frame, text="Eliminar Producto Seleccionado", command=self.eliminar_producto_gui).pack(pady=5)

        self.cargar_productos()

    def cargar_productos(self):
        for row in self.tree_productos.get_children():
            self.tree_productos.delete(row)
        try:
            registros = consultar_todos_productos()
            for r in registros:
                self.tree_productos.insert("", "end", values=r)
        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron cargar los productos.\nDetalle: {e}")

    def insertar_nuevo_producto_gui(self):
        try:
            valores = [
                int(self.producto_entries["Cod_Prod"].get()),
                self.producto_entries["Nombre"].get(),
                float(self.producto_entries["Precio"].get()),
                int(self.producto_entries["Stock"].get())
            ]
            insertar_producto(*valores)
            messagebox.showinfo("Éxito", f"Producto '{valores[1]}' insertado correctamente.")
            for entry in self.producto_entries.values():
                entry.delete(0, tk.END)
            self.cargar_productos()
        except ValueError:
            messagebox.showerror("Error de Formato", "Revise los campos numéricos.")
        except Exception as e:
            messagebox.showerror("Error de Oracle", f"No se pudo insertar el producto.\nDetalle: {e}")

    def eliminar_producto_gui(self):
        seleccion = self.tree_productos.selection()
        if not seleccion:
            messagebox.showwarning("Aviso", "Seleccione un producto para eliminar.")
            return
        item = self.tree_productos.item(seleccion[0])
        cod_prod = item['values'][3]  # COD_PROD está en la columna 3
        try:
            sql = "DELETE FROM PRODUCTOS WHERE COD_PROD = :1"
            from proyecto_oracle import ejecutar_transaccion
            ejecutar_transaccion(sql, (cod_prod,))
            messagebox.showinfo("Éxito", f"Producto '{item['values'][0]}' eliminado.")
            self.cargar_productos()
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo eliminar el producto.\nDetalle: {e}")


# EJECUCIÓN - LOOP DE TKINTER NATIVO
 
if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()
