# crear_tablas.py
import oracledb
from conexion_oracle import get_connection

conn = get_connection()
cur = conn.cursor()

# Crear las tablas según la estructura proporcionada (Restricciones ya implementadas)
cur.execute("""
CREATE TABLE CLIENTES (
    Cod_Client NUMBER(5) NOT NULL,
    Nombre VARCHAR2(30) NOT NULL,
    Apellido VARCHAR2(30) NOT NULL,
    DNI NUMBER(8) UNIQUE NOT NULL,
    Telefono NUMBER(9) NOT NULL,
    Correo VARCHAR2(30) UNIQUE NOT NULL,
    Direccion VARCHAR2(30) NOT NULL,
    CONSTRAINT PK_CLIENTES PRIMARY KEY (Cod_Client)
)
""")

cur.execute("""
CREATE TABLE PRODUCTOS (
    Cod_Prod NUMBER(8) NOT NULL, 
    Nom_Prod VARCHAR2(100) NOT NULL,
    Precio NUMBER(6, 2) NOT NULL, 
    Stock NUMBER NOT NULL,
    CONSTRAINT pk_productos PRIMARY KEY (Cod_Prod),
    CONSTRAINT chk_precio_stock CHECK (precio >= 0 AND stock >= 0)
)
""")

cur.execute("""
CREATE TABLE PEDIDOS (
    Cod_Ped NUMBER(10) NOT NULL,
    Cod_Client NUMBER(5) NOT NULL, 
    fecha_pedido DATE DEFAULT SYSDATE NOT NULL,
    estado VARCHAR2(50) DEFAULT 'Pendiente' NOT NULL,
    CONSTRAINT pk_pedidos PRIMARY KEY (Cod_Ped),
    CONSTRAINT fk_pedidos_cliente FOREIGN KEY (Cod_Client)
        REFERENCES CLIENTES(Cod_Client)
)
""")

cur.execute("""
CREATE TABLE DETALLE_PEDIDO (
    Cod_ped NUMBER NOT NULL,      
    Cod_Prod NUMBER NOT NULL,    
    Cantidad NUMBER NOT NULL,
    Precio_Total NUMBER(8, 2) NOT NULL, 
    CONSTRAINT pk_detalle_pedido PRIMARY KEY (Cod_Ped, Cod_prod),
    CONSTRAINT fk_detalle_pedido_ped FOREIGN KEY (Cod_Ped)
        REFERENCES PEDIDOS(Cod_Ped),
    CONSTRAINT fk_detalle_pedido_prod FOREIGN KEY (Cod_Prod)
        REFERENCES PRODUCTOS(Cod_Prod),      
    CONSTRAINT chk_cantidad CHECK (cantidad > 0)
)
""")

# ADICIÓN CLAVE: IMPLEMENTACIÓN DE ÍNDICES EXPLÍCITOS

try:
    print("Creando índice de optimización...")
    cur.execute("CREATE INDEX idx_cliente_apellido ON CLIENTES (Apellido)")
    print("Índice creado correctamente en CLIENTES(Apellido).")
except oracledb.Error as e:
    if e.args[0].code == 955:
        print("Advertencia: El índice ya existe.")
    else:
        raise
# ----------------------------------------------------------------------

conn.commit()
cur.close()
conn.close()
print("Tablas y estructura creadas correctamente")