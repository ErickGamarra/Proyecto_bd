import oracledb
from conexion_oracle import get_connection

# 1. Transacciones y su función 

def ejecutar_transaccion(sql, params=None, is_select=False):
    """Controla COMMIT y ROLLBACK para todas las operaciones DML/SELECT."""
    conn, cur, resultados = None, None, None
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(sql, params) if params else cur.execute(sql)

        if is_select:
            resultados = cur.fetchall()
        else:
            conn.commit() # Requisito: COMMIT
            print(f"INFO: {cur.rowcount} fila(s) afectada(s).")
            
    except oracledb.Error as e:
        print(f"ERROR DB: {e}")
        if conn and not is_select:
            conn.rollback() # Requisito: ROLLBACK
            print("INFO: Transacción revertida.")
            
    finally:
        if cur: cur.close()
        if conn: conn.close()
            
    return resultados

# 2. Operaciones CRUD

def insertar_cliente(cod, nombre, apellido, dni, tel, correo, dir):
    """CREATE (DML)."""
    sql = "INSERT INTO CLIENTES VALUES (:1, :2, :3, :4, :5, :6, :7)"
    ejecutar_transaccion(sql, (cod, nombre, apellido, dni, tel, correo, dir))

def actualizar_estado_pedido(cod_pedido, nuevo_estado):
    """UPDATE (DML)."""
    sql = "UPDATE PEDIDOS SET estado = :nuevo_estado WHERE Cod_Ped = :cod_pedido"
    ejecutar_transaccion(sql, {'nuevo_estado': nuevo_estado, 'cod_pedido': cod_pedido})

def eliminar_producto(cod_producto):
    """DELETE (DML)."""
    sql = "DELETE FROM PRODUCTOS WHERE Cod_Prod = :cod_producto"
    ejecutar_transaccion(sql, {'cod_producto': cod_producto})

# 3. Operaciones avanzadas: JOINS, subconsultas, etc.

def consultar_pedidos_con_cliente():
    """Muestra pedidos y cliente asociado usando JOINs."""
    sql = "SELECT p.Cod_Ped, c.Nombre || ' ' || c.Apellido, p.estado FROM PEDIDOS p JOIN CLIENTES c ON p.Cod_Client = c.Cod_Client"
    return ejecutar_transaccion(sql, is_select=True)

def consultar_productos_caros():
    """Usa una Subconsulta para encontrar productos más caros que el promedio."""
    sql = "SELECT Nom_Prod, Precio FROM PRODUCTOS WHERE Precio > (SELECT AVG(Precio) FROM PRODUCTOS) ORDER BY Precio DESC"
    return ejecutar_transaccion(sql, is_select=True)

def reporte_total_pedidos():
    """Calcula el monto total de cada pedido usando SUM y GROUP BY."""
    sql = "SELECT Cod_Ped, SUM(Precio_Total) FROM DETALLE_PEDIDO GROUP BY Cod_Ped ORDER BY 2 DESC"
    return ejecutar_transaccion(sql, is_select=True)

# 4. Testeo 
if __name__ == "__main__":
    
    # 1. Pruebas de CUD
    insertar_cliente(7, 'Miguel', 'Pérez', 12345678, 912345678, 'miguel.perez@test.com', 'Calle Falsa 123')
    actualizar_estado_pedido(10003, 'ENTREGADO (ACTUALIZADO)') 
    
    # 2. Pruebas de Consultas Avanzadas
    print("\n--- Resultados de JOINs ---")
    for row in consultar_pedidos_con_cliente(): print(row)
    
    print("\n--- Resultados de Subconsultas ---")
    for row in consultar_productos_caros(): print(row)
    
    print("\n--- Resultados de Agregadas (SUM/GROUP BY) ---")
    for row in reporte_total_pedidos(): print(row)